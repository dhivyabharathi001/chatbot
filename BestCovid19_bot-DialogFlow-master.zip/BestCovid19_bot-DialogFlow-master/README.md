# End-to-End Covid-19 chatbot using DialogFlow,Python/Flask,MongoDb Atlas and deployed on Pivotal Cloud foundary and Telegram
This chatbot developed using Dialoglow,python,flask,MongoDB and deployed on Telegram. search @bestcovid19_bot on telegram app
BestCovid-19 Bot can give answers of all of your queries related to covid-19 also it can -

🌟🌟🌟 DialogFlow Agents,entities,Intents backup has been added you just need to do import as zip on your Agent Setting.


I have also mentioned how to test it locally on PostMan.


Step wise implementation and Document - https://ppxa-my.sharepoint.com/:w:/g/personal/gac1507_myoffice365_app/EQVwJR-SOsFIrXT6R4vYzt8BlnIgXIXBF3NWFfpCiHSBug?e=VdmVXx


1). Show you statisics based on Country,Indian States,Indian districts,Google Maps,WorldWide


2). can send Email to user email Address.


3). Can show Live news


4). Govt annoucements , videos and Images.

If you like my work kindly hit 🌟


feel free to contact me in case of any problem reachout to me @ 'dineshraturi22@gmail.com' and Add subject-BestCovid Query

